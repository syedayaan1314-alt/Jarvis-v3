export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "Server setup is incomplete: GEMINI_API_KEY is not configured in Vercel." });
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "Please enter a message." });
  if (message.length > 8000) return res.status(413).json({ error: "Message is too long. Please shorten it." });
  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: "You are JARVIS, a helpful, clear, respectful personal AI assistant. Address the user as Sir when natural. Be honest about limitations and never claim to control a device or account unless a real integration is available." }] },
        contents: [{ role: "user", parts: [{ text: message }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      const detail = data?.error?.message || "Gemini request failed.";
      return res.status(response.status >= 400 && response.status < 600 ? response.status : 502).json({ error: detail });
    }
    const reply = (data.candidates?.[0]?.content?.parts || []).map(part => part.text || "").join("").trim();
    if (!reply) return res.status(502).json({ error: "Gemini returned an empty response. Please try again." });
    return res.status(200).json({ reply });
  } catch {
    return res.status(502).json({ error: "Could not connect to the AI provider. Try again shortly." });
  }
}